
const SocialMedia = () => {

    return (
        <>
            <div className="container-fluid" id="SocialMedia">
                <h1>SocialMedia</h1>
            </div>

        </>
    )
}
export default SocialMedia;