
const ClassifiedAds = () => {

    return (
        <>
            <div className="container-fluid" id="ClassifiedAds">
                <h1>ClassifiedAds</h1>

                <div className="container  text-center">
                    <img src="public/dis&classAds.jpeg" className="img-fluid w-100" alt="" />
                </div>

                <div className="container mt-5 text-center" >
                    <img src="public/ClassifiedAds1.jpeg" alt="" />
                </div>
            </div>

        </>
    )
}

export default ClassifiedAds;