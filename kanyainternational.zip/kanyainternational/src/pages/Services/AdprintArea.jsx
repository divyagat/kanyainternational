
const AdprintArea = () => {

    return (
        <>

            <div className="container-fluid" id="AdprintArea">
                <h1>AdprintArea</h1>
            </div>

        </>
    )
}
export default AdprintArea;