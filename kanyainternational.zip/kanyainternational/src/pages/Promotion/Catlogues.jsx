
const Catalogues = () => {
    return (
        <>

            <div className="container-fluid" id="Catalogues">
                <h1>Catalogues</h1>
            </div>

        </>
    )
}
export default Catalogues;