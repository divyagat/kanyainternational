import React from 'react';

const Work = () => {
  return (
    <>
    <h1>Work</h1>
    </>
  );
};

export default Work;
